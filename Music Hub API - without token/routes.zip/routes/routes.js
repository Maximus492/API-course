
const express = require('express');
const Model = require('../model/model');
const Album = require('../model/album');
const router = express.Router();






////////////////////////////////////////////////////////////////////////////album
//Post method
router.post('/postAlbum', async (req, res) => {

    const data = new Album({
        albumID: req.body.albumID,
        albumName: req.body.albumName,
        artist: req.body.artist, 
        yearReleased: req.body.yearReleased, 
        genres: req.body.genres, 
        length: req.body.length, 
        label: req.body.label, 
        producer: req.body.producer 
    });

    try {
        const dataToSave = await data.save();
        res.status(200).json(dataToSave)
        console.log(dataToSave)

    }
    catch(error){
        res.status(400).json({message: error.message})

    }
})

//Get All Method
router.get('/getAllAlbums', async (req, res) => {
    try{
        const data = await Album.find();
        res.json(data);
    }
    catch(error){
        res.status(500).json({message: error.message})
    }
})

//Get by ID Method
router.get('/getOneAlbum/:id', async (req,res) => {
    try{
        const data = await Album.findById(req.params.id);
        res.json(data);
    }
    catch(error){
        res.status(500).json({message: error.message})
    }
})

//Update by ID Method
router.patch('/updateAlbum/:id', async (req, res) => {
    try{
        const id = req.params.id;
        const updatedData = req.body;
        const options = { new: true };

        const result = await Album.findByIdAndUpdate(id, updatedData, options);

        res.json(result);
    }
    catch(error){
        res.status(400).json({message: error.message})
    }
})

//Delete by ID method
router.delete('/delete/:id', async (req, res) => {
    try{
        const id = req.params.id;
        const data = await Album.findByIdAndDelete(id);
        res.send(`Album with ${data.name} has been deleted..`);
    }  //  IMPORTANT use ` not ' so ${data.name} is read properly
    catch(error){
        res.status(400).json({message: error.message})
    }
})










////////////////////////////////////////////////////////////////////////////model
//Post method
router.post('/post', async (req, res) => {

    const data = new Model({
        name: req.body.name,
        age: req.body.age
    });


    try {
        const dataToSave = await data.save();
        res.status(200).json(dataToSave)
        console.log(dataToSave)

    }
    catch(error){
        res.status(400).json({message: error.message})

    }
})

//Get All Method
router.get('/getAll', async (req, res) => {
    try{
        const data = await Model.find();
        res.json(data);
    }
    catch(error){
        res.status(500).json({message: error.message})
    }
})

//Get by ID Method
router.get('/getOne/:id', async (req,res) => {
    try{
        const data = await Model.findById(req.params.id);
        res.json(data);
    }
    catch(error){
        res.status(500).json({message: error.message})
    }
})

//Update by ID Method
router.patch('/update/:id', async (req, res) => {
    try{
        const id = req.params.id;
        const updatedData = req.body;
        const options = { new: true };

        const result = await Model.findByIdAndUpdate(id, updatedData, options);

        res.json(result);
    }
    catch(error){
        res.status(400).json({message: error.message})
    }
})

//Delete by ID method
router.delete('/delete/:id', async (req, res) => {
    try{
        const id = req.params.id;
        const data = await Model.findByIdAndDelete(id);
        res.send(`Document with ${data.name} has been deleted..`);
    }  //  IMPORTANT use ` not ' so ${data.name} is read properly
    catch(error){
        res.status(400).json({message: error.message})
    }
})
//////////////////////////////////////////////////////////////////model





module.exports = router;