const mongoose = require('mongoose');

const dataSchema = new mongoose.Schema({
    /*
    genre_id: {
        required: true,
        type: String
    },
    */
    genre: {
        require: true,
        type: Number
    },
    genre_description: {
        require: true,
        type: Number
    }
})

module.exports = mongoose.model('Genre', dataSchema)