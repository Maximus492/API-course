const mongoose = require('mongoose');

const dataSchema = new mongoose.Schema({
    artist_id: {
        required: true,
        type: String
    },
    artist_name: {
        require: true,
        type: Number
    },
    single_band_name: {
        require: true,
        type: Number
    }
})

module.exports = mongoose.model('Artist', dataSchema)