const mongoose = require('mongoose');

const dataSchema1 = new mongoose.Schema({
    album_id: {
        required: true,
        type: Number
    },
    album_name: {
        required: true,
        type: String
    },

    artist: [
        {
        artist_id: {
        required: true,
        type: String
        },
        artist_name: {
        required: true,
        type: String
        }
    }
    ],   


    /*
    artist: {
        required: true,
        type: String
    },
    */

    /*
    "movies_rented": [
        {
          "id_movies": 6,
          "title": "Dungeons and Dragons: Honor among Thieves"
        },
        {
          "id_movies": 7,
          "title": "Asteroid City"
        },
        {
          "id_movies": 9,
          "title": "Guardians of the Galaxy Vol 3"
        }
      ],
*/

    year_released: {
        required: true,
        type: String
        /*
        required: true,
        type: String,
        pattern: "^\\d{2}-\\d{2}-\\d{4}$"*/
    },
    genres: {
        required: true,
        type: String
    },
    length: {
        required: true,
        type: Number
    },
    label: {
        required: true,
        type: String
    },
    producer: {
        required: true,
        type: String
    },
    total_tracks: {
        required: true,
        type: Number
    }
})

module.exports = mongoose.model('Album', dataSchema1)

/*
"albumID": ,
"albumName": "",
"artist": "", 
"yearReleased": 00-00-0000, 
"genres": "", 
"length": , 
"label": "", 
"producer": "" 
*/






/*
"albumID": ,                        // int
"albumName": "",                    // string
"artist": "",                       // string
"artist": [
    {
      "artist_id": 6,               // string
      "artist_name": ""             // int
    },
  ],
"year_released": 00-00-0000,        // string
"genres": "",                       // string
"length": ,                         // int
"label": "",                        // string
"producer": ""                      // string
"total_tracks": ,                   // int
*/